<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dosen extends CI_Controller {
    public function index(){
        $this->load->model('dosen_model', 'dosen');
        $list_dosen = $this->dosen->getAll();

        $data['list_dosen'] = $list_dosen;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/index',$data);
        $this->load->view('layout/footer');
    }

    public function view(){
        $_nidn = $this->input->get('id');
        $this->load->model('dosen_model', 'dosen'); //panggil model
        $data['dsn'] = $this->dosen->findById($_nidn);

        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/view',$data);
        $this->load->view('layout/footer');
    }

        public function create(){
        $data['judul'] = "Form Kelola Dosen";
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/create',$data);
        $this->load->view('layout/footer');
    }

    public function save(){
        //panggil model
        $this->load->model('dosen_model','dosen');
        
        $nidn = $this->input->post('nidn');
        $nama = $this->input->post('nama');
        $gender = $this->input->post('gender');
        $tmp_lahir = $this->input->post('tmp_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $pendidikan_akhir = $this->input->post('pendidikan_akhir');
        $prodi_kode = $this->input->post('prodi_kode');
        $idedit = $this->input->post('idedit'); //hidden field, ada kalo update

        //buat array 
        $data_dsn[] = $nidn; // 1
        $data_dsn[] = $nama; // 2
        $data_dsn[] = $gender; // 3
        $data_dsn[] = $tmp_lahir; // 4
        $data_dsn[] = $tgl_lahir; // 5
        $data_dsn[] = $pendidikan_akhir; // 6
        $data_dsn[] = $prodi_kode; // 7
        //dimasukin ke $data_dsn dibawah 

        if(isset($idedit)){
            //update data lama
            $data_dsn[] = $idedit; // 8
            $this->dosen->update($data_dsn); //data harus berupa array
        }else{
            //save data baru
            // panggil fungsi save yg ada di model
            $this->dosen->save($data_dsn); //data harus berupa array
        }

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/dosen/view?id='.$nidn,'refresh');
        //base url dari config = localhost/webkampus/   
    }

    //method, form = post
    //url = get
    public function edit(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('dosen_model','dosen');
        $dsn_edit = $this->dosen->findById($id);

        $data['judul'] = "Form Edit Dosen";
        $data['dsn_edit'] = $dsn_edit;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('dosen/update',$data);
        $this->load->view('layout/footer');
    }

    public function delete(){
        $id = $this->input->get('id');
        //panggil model
        $this->load->model('dosen_model','dosen');
        $this->dosen->delete($id);

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/dosen','refresh');
    }
}